from models.models import Venta, Cliente, Producto

def registrar_venta(cliente_id, producto_id, cantidad):
    if not cantidad:
        raise ValueError("La cantidad es obligatoria.")
    try:
        cantidad = int(cantidad)
        if cantidad <= 0:
            raise ValueError("Cantidad debe ser mayor a 0.")
    except ValueError:
        raise ValueError("Cantidad inválida.")
    venta = Venta.create(cliente=cliente_id, producto=producto_id, cantidad=cantidad)
    return venta

def obtener_ventas():
    return Venta.select().order_by(Venta.fecha.desc())
