from models.models import Cliente

def agregar_cliente(nombre, correo):
    if not nombre or not correo:
        raise ValueError("Todos los campos son obligatorios.")
    if "@" not in correo:
        raise ValueError("Correo inválido.")
    cliente = Cliente.create(nombre=nombre, correo=correo)
    return cliente
