import tkinter as tk
from tkinter import ttk

class MainView:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Ventas")

        ttk.Label(root, text="Bienvenido al Sistema de Ventas", font=("Arial", 16)).pack(pady=15)

        boton_frame = ttk.Frame(root, padding=10)
        boton_frame.pack()

        ttk.Button(boton_frame, text="Registrar Producto", command=self.abrir_producto, width=25).pack(pady=5)
        ttk.Button(boton_frame, text="Registrar Cliente", command=self.abrir_cliente, width=25).pack(pady=5)
        ttk.Button(boton_frame, text="Registrar Venta", command=self.abrir_venta, width=25).pack(pady=5)
        ttk.Button(boton_frame, text="Ver Ventas", command=self.ver_ventas, width=25).pack(pady=5)

    def abrir_producto(self):
        from views.producto_view import ProductoView
        ProductoView()

    def abrir_cliente(self):
        from views.cliente_view import ClienteView
        ClienteView()

    def abrir_venta(self):
        from views.venta_view import VentaView
        VentaView()

    def ver_ventas(self):
        from views.venta_view import mostrar_ventas
        mostrar_ventas()
