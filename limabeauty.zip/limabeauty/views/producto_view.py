import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from controllers.producto_controller import agregar_producto

class ProductoView:
    def __init__(self):
        self.ventana = tk.Toplevel()
        self.ventana.title("Agregar Producto")

        ttk.Label(self.ventana, text="Nombre:").pack(pady=5)
        self.nombre_entry = ttk.Entry(self.ventana)
        self.nombre_entry.pack()

        ttk.Label(self.ventana, text="Precio:").pack(pady=5)
        self.precio_entry = ttk.Entry(self.ventana)
        self.precio_entry.pack()

        ttk.Button(self.ventana, text="Guardar", command=self.guardar).pack(pady=10)

    def guardar(self):
        nombre = self.nombre_entry.get()
        precio = self.precio_entry.get()
        try:
            agregar_producto(nombre, precio)
            messagebox.showinfo("Éxito", "Producto agregado correctamente.")
            self.ventana.destroy()
        except Exception as e:
            messagebox.showerror("Error", str(e))
