from peewee import *
from datetime import datetime

# Conexión a la base de datos SQLite
db = SqliteDatabase('tienda.db')

# BaseModel para establecer la conexión con la base de datos
class BaseModel(Model):
    class Meta:
        database = db

# Definir el modelo Producto
class Producto(BaseModel):
    nombre = CharField()
    precio = FloatField()

# Definir el modelo Cliente
class Cliente(BaseModel):
    nombre = CharField()
    correo = CharField()

# Definir el modelo Venta
class Venta(BaseModel):
    cliente = ForeignKeyField(Cliente, backref='ventas')
    producto = ForeignKeyField(Producto, backref='ventas')
    cantidad = IntegerField()
    fecha = DateTimeField(default=datetime.now)  # Fecha y hora de la venta

# Función para crear las tablas si no existen
def crear_tablas():
    with db:
        db.create_tables([Producto, Cliente, Venta], safe=True)
