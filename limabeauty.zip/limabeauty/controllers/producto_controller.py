from models.models import Producto

def agregar_producto(nombre, precio):
    if not nombre or not precio:
        raise ValueError("Todos los campos son obligatorios.")
    try:
        precio = float(precio)
    except ValueError:
        raise ValueError("El precio debe ser numérico.")
    producto = Producto.create(nombre=nombre, precio=precio)
    return producto
