import tkinter as tk
from tkinter import ttk, messagebox
from models.models import Cliente, Producto
from controllers.venta_controller import registrar_venta, obtener_ventas

class VentaView:
    def __init__(self):
        self.ventana = tk.Toplevel()
        self.ventana.title("Registrar Venta")

        ttk.Label(self.ventana, text="Cliente:").pack(pady=5)
        self.cliente_cb = ttk.Combobox(self.ventana, values=[f"{c.id} - {c.nombre}" for c in Cliente.select()])
        self.cliente_cb.pack()

        ttk.Label(self.ventana, text="Producto:").pack(pady=5)
        self.producto_cb = ttk.Combobox(self.ventana, values=[f"{p.id} - {p.nombre}" for p in Producto.select()])
        self.producto_cb.pack()

        ttk.Label(self.ventana, text="Cantidad:").pack(pady=5)
        self.cantidad_entry = ttk.Entry(self.ventana)
        self.cantidad_entry.pack()

        ttk.Button(self.ventana, text="Registrar", command=self.guardar).pack(pady=10)

    def guardar(self):
        try:
            cliente_id = int(self.cliente_cb.get().split(" - ")[0])
            producto_id = int(self.producto_cb.get().split(" - ")[0])
            cantidad = self.cantidad_entry.get()
            registrar_venta(cliente_id, producto_id, cantidad)
            messagebox.showinfo("Éxito", "Venta registrada correctamente.")
            self.ventana.destroy()
        except Exception as e:
            messagebox.showerror("Error", str(e))

def mostrar_ventas():
    ventana = tk.Toplevel()
    ventana.title("Listado de Ventas")

    frame = ttk.Frame(ventana)
    frame.pack(fill=tk.BOTH, expand=True)

    tree = ttk.Treeview(frame, columns=("cliente", "producto", "cantidad", "fecha", "total"), show="headings")
    scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)

    tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    for col in tree["columns"]:
        tree.heading(col, text=col.capitalize())

    for venta in obtener_ventas():
        total = venta.producto.precio * venta.cantidad
        tree.insert("", tk.END, values=(
            venta.cliente.nombre,
            venta.producto.nombre,
            venta.cantidad,
            venta.fecha.strftime("%Y-%m-%d %H:%M"),
            f"${total:.2f}"
        ))
