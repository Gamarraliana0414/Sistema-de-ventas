import customtkinter as ctk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime
import random

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de Venta Lima Beauty")
        self.geometry("1000x600")

        self.fondo_morado = "#c58af9"
        self.fondo_sidebar = "#a06cd5"
        self.configure(bg_color=self.fondo_morado)

        self.clientes = []
        self.ventas = []
        self.productos = []

        # Header
        header = ctk.CTkFrame(self, height=50, fg_color=self.fondo_morado)
        header.pack(fill="x", side="top")

        titulo = ctk.CTkLabel(header, text="SISTEMA DE VENTA LIMA BEAUTY",
                              font=ctk.CTkFont(size=22, weight="bold"), text_color="white")
        titulo.place(relx=0.5, rely=0.5, anchor="center")

        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=180, fg_color=self.fondo_sidebar)
        self.sidebar.pack(side="left", fill="y")

        buttons = [
            ("Inicio", self.mostrar_inicio),
            ("Registrar Cliente", self.registrar_cliente),
            ("Registrar Producto", self.registrar_producto),
            ("Registrar Venta", self.registrar_venta),
            ("Ver Ventas", self.ver_ventas)
        ]

        for text, cmd in buttons:
            ctk.CTkButton(self.sidebar, text=text, command=cmd, fg_color="#8e44ad",
                          hover_color="#732d91", corner_radius=8).pack(pady=10, padx=10, fill="x")

        # Main Panel
        self.main = ctk.CTkFrame(self, corner_radius=10, fg_color="white")
        self.main.pack(expand=True, fill="both", padx=20, pady=20)

        self.mostrar_inicio()

    def limpiar_main(self):
        for widget in self.main.winfo_children():
            widget.destroy()

    def mostrar_inicio(self):
        self.limpiar_main()

        resumen = ctk.CTkFrame(self.main, fg_color="white")
        resumen.pack(pady=10)

        for texto, valor in [("Clientes", len(self.clientes)), ("Productos", len(self.productos)), ("Ventas", len(self.ventas))]:
            card = ctk.CTkFrame(resumen, width=150, height=80, fg_color="#f3e9ff")
            card.pack(side="left", padx=10)
            ctk.CTkLabel(card, text=str(valor), font=ctk.CTkFont(size=18, weight="bold"), text_color="black").pack()
            ctk.CTkLabel(card, text=texto, font=ctk.CTkFont(size=14), text_color="gray").pack()

        # Gráfico ficticio
        fig = Figure(figsize=(5, 3), dpi=100)
        plot = fig.add_subplot(111)
        datos = [random.randint(50, 150) for _ in range(6)]
        plot.plot(datos, marker='o', color='#8e44ad')
        plot.set_title("Rendimiento de Ventas")

        canvas = FigureCanvasTkAgg(fig, master=self.main)
        canvas.draw()
        canvas.get_tk_widget().pack(pady=20)

    def registrar_cliente(self):
        self.limpiar_main()
        ctk.CTkLabel(self.main, text="Registrar Cliente", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)

        nombre = ctk.CTkEntry(self.main, placeholder_text="Nombre del cliente")
        nombre.pack(pady=5)
        correo = ctk.CTkEntry(self.main, placeholder_text="Correo")
        correo.pack(pady=5)

        mensaje = ctk.CTkLabel(self.main, text="")
        mensaje.pack(pady=5)

        def guardar():
            if nombre.get() and correo.get():
                self.clientes.append({"nombre": nombre.get(), "correo": correo.get()})
                mensaje.configure(text="Cliente guardado correctamente ✅", text_color="green")
                nombre.delete(0, 'end')
                correo.delete(0, 'end')
            else:
                mensaje.configure(text="Completa todos los campos", text_color="red")

        ctk.CTkButton(self.main, text="Guardar", command=guardar).pack(pady=10)

    def registrar_producto(self):
        self.limpiar_main()
        ctk.CTkLabel(self.main, text="Registrar Producto", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)

        nombre = ctk.CTkEntry(self.main, placeholder_text="Nombre del producto")
        nombre.pack(pady=5)
        precio = ctk.CTkEntry(self.main, placeholder_text="Precio (solo número)")
        precio.pack(pady=5)

        mensaje = ctk.CTkLabel(self.main, text="")
        mensaje.pack(pady=5)

        def guardar():
            try:
                if nombre.get() and precio.get():
                    precio_num = float(precio.get())
                    self.productos.append({"nombre": nombre.get(), "precio": precio_num})
                    mensaje.configure(text="Producto registrado ✅", text_color="green")
                    nombre.delete(0, 'end')
                    precio.delete(0, 'end')
                else:
                    mensaje.configure(text="Completa todos los campos", text_color="red")
            except:
                mensaje.configure(text="Precio inválido", text_color="red")

        ctk.CTkButton(self.main, text="Guardar", command=guardar).pack(pady=10)

    def registrar_venta(self):
        self.limpiar_main()
        ctk.CTkLabel(self.main, text="Registrar Venta", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)

        if not self.clientes or not self.productos:
            ctk.CTkLabel(self.main, text="⚠️ Registra al menos un cliente y un producto primero.").pack(pady=10)
            return

        cliente_menu = ctk.CTkOptionMenu(self.main, values=[c["nombre"] for c in self.clientes])
        cliente_menu.pack(pady=5)

        producto_menu = ctk.CTkOptionMenu(self.main, values=[p["nombre"] for p in self.productos])
        producto_menu.pack(pady=5)

        cantidad = ctk.CTkEntry(self.main, placeholder_text="Cantidad")
        cantidad.pack(pady=5)

        total_label = ctk.CTkLabel(self.main, text="Total: $0")
        total_label.pack(pady=5)

        mensaje = ctk.CTkLabel(self.main, text="")
        mensaje.pack(pady=5)

        def calcular():
            try:
                cantidad_val = int(cantidad.get())
                producto_seleccionado = next((p for p in self.productos if p["nombre"] == producto_menu.get()), None)
                if producto_seleccionado:
                    total = producto_seleccionado["precio"] * cantidad_val
                    total_label.configure(text=f"Total: ${total:.2f}")
            except:
                total_label.configure(text="Error al calcular total")

        def guardar():
            cliente = next((c for c in self.clientes if c["nombre"] == cliente_menu.get()), None)
            producto = next((p for p in self.productos if p["nombre"] == producto_menu.get()), None)
            if cliente and producto and cantidad.get():
                try:
                    cantidad_val = int(cantidad.get())
                    total = producto["precio"] * cantidad_val
                    self.ventas.append({
                        "cliente": cliente["nombre"],
                        "correo": cliente["correo"],
                        "producto": producto["nombre"],
                        "cantidad": cantidad_val,
                        "total": total
                    })
                    mensaje.configure(text="Venta registrada ✅", text_color="green")
                    cantidad.delete(0, 'end')
                    total_label.configure(text="Total: $0")
                except:
                    mensaje.configure(text="Error en cantidad", text_color="red")
            else:
                mensaje.configure(text="Completa todos los campos", text_color="red")

        ctk.CTkButton(self.main, text="Calcular Total", command=calcular).pack(pady=5)
        ctk.CTkButton(self.main, text="Guardar", command=guardar).pack(pady=10)

    def ver_ventas(self):
        self.limpiar_main()
        ctk.CTkLabel(self.main, text="Listado de Ventas", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)

        if not self.ventas:
            ctk.CTkLabel(self.main, text="No hay ventas registradas.").pack(pady=10)
            return

        for venta in self.ventas:
            texto = (f"Cliente: {venta['cliente']} | Correo: {venta['correo']} | "
                     f"Producto: {venta['producto']} | Cantidad: {venta['cantidad']} | Total: ${venta['total']:.2f}")
            ctk.CTkLabel(self.main, text=texto, anchor="w", justify="left").pack(anchor="w", padx=20, pady=2)


if __name__ == "__main__":
    app = App()
    app.mainloop()
